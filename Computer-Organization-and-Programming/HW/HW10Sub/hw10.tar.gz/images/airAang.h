/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=75x70 airAang airAang.png 
 * Time-stamp: Tuesday 11/20/2018, 18:41:42
 * 
 * Image Information
 * -----------------
 * airAang.png 75@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AIRAANG_H
#define AIRAANG_H

extern const unsigned short airAang[5250];
#define AIRAANG_SIZE 10500
#define AIRAANG_LENGTH 5250
#define AIRAANG_WIDTH 75
#define AIRAANG_HEIGHT 70

#endif

