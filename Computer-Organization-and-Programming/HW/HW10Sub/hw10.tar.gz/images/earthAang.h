/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=75x70 earthAang earthAang.png 
 * Time-stamp: Tuesday 11/20/2018, 18:41:57
 * 
 * Image Information
 * -----------------
 * earthAang.png 75@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EARTHAANG_H
#define EARTHAANG_H

extern const unsigned short earthAang[5250];
#define EARTHAANG_SIZE 10500
#define EARTHAANG_LENGTH 5250
#define EARTHAANG_WIDTH 75
#define EARTHAANG_HEIGHT 70

#endif

