/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x17 fireball fireball.png 
 * Time-stamp: Monday 11/19/2018, 18:42:52
 * 
 * Image Information
 * -----------------
 * fireball.png 15@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIREBALL_H
#define FIREBALL_H

extern const unsigned short fireball[255];
#define FIREBALL_SIZE 510
#define FIREBALL_LENGTH 255
#define FIREBALL_WIDTH 15
#define FIREBALL_HEIGHT 17

#endif

