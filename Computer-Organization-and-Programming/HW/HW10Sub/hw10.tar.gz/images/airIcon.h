/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=33x31 airIcon airIcon.png 
 * Time-stamp: Tuesday 11/20/2018, 12:57:32
 * 
 * Image Information
 * -----------------
 * airIcon.png 33@31
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AIRICON_H
#define AIRICON_H

extern const unsigned short airIcon[1023];
#define AIRICON_SIZE 2046
#define AIRICON_LENGTH 1023
#define AIRICON_WIDTH 33
#define AIRICON_HEIGHT 31

#endif

