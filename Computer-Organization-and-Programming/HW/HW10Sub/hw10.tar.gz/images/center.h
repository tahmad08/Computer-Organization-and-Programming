/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=75x70 center center.png 
 * Time-stamp: Tuesday 11/20/2018, 16:35:08
 * 
 * Image Information
 * -----------------
 * center.png 75@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CENTER_H
#define CENTER_H

extern const unsigned short center[5250];
#define CENTER_SIZE 10500
#define CENTER_LENGTH 5250
#define CENTER_WIDTH 75
#define CENTER_HEIGHT 70

#endif

