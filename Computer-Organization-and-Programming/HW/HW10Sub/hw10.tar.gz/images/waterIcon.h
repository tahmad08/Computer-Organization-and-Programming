/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=32x30 waterIcon waterIcon.png 
 * Time-stamp: Tuesday 11/20/2018, 12:57:53
 * 
 * Image Information
 * -----------------
 * waterIcon.png 32@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WATERICON_H
#define WATERICON_H

extern const unsigned short waterIcon[960];
#define WATERICON_SIZE 1920
#define WATERICON_LENGTH 960
#define WATERICON_WIDTH 32
#define WATERICON_HEIGHT 30

#endif

