/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=31x43 closedMan closedMan.png 
 * Time-stamp: Monday 11/19/2018, 18:04:23
 * 
 * Image Information
 * -----------------
 * closedMan.png 31@43
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CLOSEDMAN_H
#define CLOSEDMAN_H

extern const unsigned short closedMan[1333];
#define CLOSEDMAN_SIZE 2666
#define CLOSEDMAN_LENGTH 1333
#define CLOSEDMAN_WIDTH 31
#define CLOSEDMAN_HEIGHT 43

#endif

