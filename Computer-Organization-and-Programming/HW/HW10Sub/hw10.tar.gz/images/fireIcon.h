/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=34x34 fireIcon fireIcon.png 
 * Time-stamp: Tuesday 11/20/2018, 12:10:03
 * 
 * Image Information
 * -----------------
 * fireIcon.png 34@34
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIREICON_H
#define FIREICON_H

extern const unsigned short fireIcon[1156];
#define FIREICON_SIZE 2312
#define FIREICON_LENGTH 1156
#define FIREICON_WIDTH 34
#define FIREICON_HEIGHT 34

#endif

