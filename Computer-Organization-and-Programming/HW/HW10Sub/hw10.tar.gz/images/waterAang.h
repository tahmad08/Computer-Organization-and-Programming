/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=75x70 waterAang waterAang.png 
 * Time-stamp: Tuesday 11/20/2018, 18:41:20
 * 
 * Image Information
 * -----------------
 * waterAang.png 75@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WATERAANG_H
#define WATERAANG_H

extern const unsigned short waterAang[5250];
#define WATERAANG_SIZE 10500
#define WATERAANG_LENGTH 5250
#define WATERAANG_WIDTH 75
#define WATERAANG_HEIGHT 70

#endif

