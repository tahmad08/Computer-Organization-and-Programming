/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=31x43 openMan openMan.png 
 * Time-stamp: Monday 11/19/2018, 18:04:35
 * 
 * Image Information
 * -----------------
 * openMan.png 31@43
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef OPENMAN_H
#define OPENMAN_H

extern const unsigned short openMan[1333];
#define OPENMAN_SIZE 2666
#define OPENMAN_LENGTH 1333
#define OPENMAN_WIDTH 31
#define OPENMAN_HEIGHT 43

#endif

