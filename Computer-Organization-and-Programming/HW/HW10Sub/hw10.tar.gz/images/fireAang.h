/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=75x70 fireAang fireAang.png 
 * Time-stamp: Tuesday 11/20/2018, 18:41:32
 * 
 * Image Information
 * -----------------
 * fireAang.png 75@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIREAANG_H
#define FIREAANG_H

extern const unsigned short fireAang[5250];
#define FIREAANG_SIZE 10500
#define FIREAANG_LENGTH 5250
#define FIREAANG_WIDTH 75
#define FIREAANG_HEIGHT 70

#endif

