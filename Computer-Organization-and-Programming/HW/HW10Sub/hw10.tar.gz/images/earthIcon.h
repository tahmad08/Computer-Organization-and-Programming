/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=32x31 earthIcon earthIcon.png 
 * Time-stamp: Tuesday 11/20/2018, 15:34:47
 * 
 * Image Information
 * -----------------
 * earthIcon.png 32@31
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EARTHICON_H
#define EARTHICON_H

extern const unsigned short earthIcon[992];
#define EARTHICON_SIZE 1984
#define EARTHICON_LENGTH 992
#define EARTHICON_WIDTH 32
#define EARTHICON_HEIGHT 31

#endif

