-----------------------------------------------
Press SELECT to play, and press START
to play with animation
-----------------------------------------------
INSTRUCTIONS FOR GAME:

Use the left and right arrow keys to pick 
between one of the three avatars. The avatars
must avoid the falling fire and catch the arrows. 
To toggle an avatars state (between airbending 
away the fire and catching the arrows). You have 
five lives. Losing all of them means the end 
of the game.

Press SELECT at any time to return to main

-----------------------------------------------

ANIMATION: Use the arrow keys to touch one
of the elements and watch Aang bend.

Press SELECT at any time to return to main

-----------------------------------------------
