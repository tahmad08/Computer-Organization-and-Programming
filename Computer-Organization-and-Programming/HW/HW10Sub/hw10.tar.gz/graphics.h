#ifndef GRAPHICS_SEEN
#define GRAPHICS_SEEN

#include "logic.h"

// Button Variables
extern unsigned short buttons;
extern unsigned short oldButtons;

extern int state;

//characters
extern char buffer[];

void init(void);

// State Prototypes
void start(void);
void game(void);
void win(void);
void lose(void);
void instr(void);
void pause(void);
void goToStart(void);
void goToInstr(void);
void goToGame(void);
void goToWin(void);
void goToLose(void);
void goToPause(void);

int collision(PLAYER *player, OBJECT *object);
int collision2(int rowA, int colA, int heightA, int widthA, int rowB, int colB, int heightB, int widthB);
int collision3(PLAYER *a, PLAYER *b);




#endif
