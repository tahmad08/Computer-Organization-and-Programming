#include <stdio.h>
#include <stdlib.h>
#include "gba.h"
#include "logic.h"
#include "graphics.h"
#include "anim.h"
#include "images/center.h"
#include "images/fireIcon.h"
#include "images/airIcon.h"
#include "images/waterIcon.h"
#include "images/earthIcon.h"
#include "images/ball.h"
#include "images/waterAang.h"
#include "images/fireAang.h"
#include "images/earthAang.h"
#include "images/airAang.h"


PLAYER aang;
OBJECT water;
OBJECT air;
OBJECT fire;
OBJECT earth;

PLAYER ballo;

int elem;
int collided;

void initAnim(void) {
	elem = 0;
	collided = 0;
	initAang();
	initElem();
}
  
void drawAnim(void) {
	drawParts();
	drawBall();
}
void updateAnim(unsigned short buttons, unsigned short oldButtons) {
	int elem = updateBall(buttons, oldButtons, &ballo);
	updateAang(elem);
}

int updateBall(unsigned short buttons, unsigned short oldButtons, PLAYER *player) {
	UNUSED(oldButtons);
	UNUSED(player);
	if(ballo.col - 3 < (air.col + air.width) && ballo.row - 4 < air.height) {
		collided = 1;
		//return 1;
	}
	else if(ballo.col + ballo.width + 2 > fire.col && ballo.row - 4 < fire.height) {
		collided = 2;
		//return 2;
	}
	else if(ballo.col -2 < (earth.col + earth.width) && ballo.row + ballo.height + 4 > earth.row) {
		collided = 3;
		//return 3;  
	}
	else if(ballo.col + ballo.width + 2 > water.col 
		&& ballo.row +ballo.height + 4 > water.row) {
		collided = 4;
		//return 4;
	}
	if(KEY_DOWN(BUTTON_RIGHT, buttons) && (ballo.col + ballo.width < WIDTH-1)
		&& !((ballo.col + ballo.width + 2 >= water.col && ballo.row + ballo.height > water.row - 2))
		&& !(ballo.col + ballo.width +  3> fire.col && ballo.row - 4 < fire.height)
		&& !(collision3(&aang, &ballo)))
		//!(ballo.col + ballo.width + 3 > aang.col))
	{

		ballo.oldcol = ballo.col;
		ballo.col += ballo.cdel;
	}
	if(KEY_DOWN(BUTTON_LEFT, buttons) && ballo.col > 1
		&& !(ballo.col - 3 < (air.col + air.width) && ballo.row - 4 < air.height)
		&& !(ballo.col -2 < (earth.col + earth.width) && ballo.row + ballo.height + 4 > earth.row)
		&& !(collision3(&aang, &ballo))	)	{
		//!(ball.col - 2 < aang.col+aang.width)){
		ballo.oldcol = ballo.col;
		ballo.col -= ballo.cdel;
	}
	if(KEY_DOWN(BUTTON_UP, buttons) && ballo.row > 1
		&& !(ballo.col - 3 < (air.col + air.width) && ballo.row - 4 < air.height)
		&& !((ballo.col + ballo.width + 3 > fire.col && ballo.row - 4 < fire.height))
		&& !(collision3(&aang, &ballo))){
		ballo.oldrow = ballo.row;
		ballo.row -= ballo.rdel;
	}
	if(KEY_DOWN(BUTTON_DOWN, buttons) && ballo.row + ballo.height < HEIGHT - 1
		&& !((ballo.col + ballo.width + 2 > water.col && ballo.row +ballo.height + 3 > water.row))
		&& !(ballo.col -2 < (earth.col + earth.width) && ballo.row + ballo.height + 4 > earth.row)
		&& !(collision3(&aang, &ballo))){
		ballo.oldrow = ballo.row;
		ballo.row += ballo.rdel;
	}
	return collided;

}

void updateAang(int element) {
	if(element == 0 || element == 5) {
		//collided = 0;
		return;
	} else if (element == 1) {
		//air
		//collided = 0;
		aang.open = airAang;
		return;
	} else if (element == 2) {
		//fire
		//collided = 0;
		aang.open = fireAang;
		return;
	} else if (element == 3) {
		//earth
		//collided = 0;
		aang.open = earthAang;
		return;
	} else if (element == 4) {
		//water
		//collided = 0;
		aang.open = waterAang;
		return;
	}

}

void drawBall(void) {
	drawRectDMA(ballo.oldrow, ballo.oldcol, BALL_WIDTH, BALL_HEIGHT, LIGHTGRAY);
	drawImageDMA(ballo.row, ballo.col, BALL_WIDTH, BALL_HEIGHT, ball);
}
void drawParts(void) {
	drawImageDMA(aang.row , aang.col, CENTER_WIDTH, CENTER_HEIGHT, aang.open);
	drawImageDMA(air.row, air.col, AIRICON_WIDTH, AIRICON_HEIGHT, airIcon);
	drawImageDMA(fire.row, fire.col, FIREICON_WIDTH, FIREICON_HEIGHT, fireIcon);
	drawImageDMA(water.row, water.col, WATERICON_WIDTH, WATERICON_HEIGHT, waterIcon);
	drawImageDMA(earth.row, earth.col, EARTHICON_WIDTH, EARTHICON_HEIGHT, earthIcon);

}
void initAang(void) {  
	aang.height = CENTER_HEIGHT;
	aang.width = CENTER_WIDTH;
	aang.row = 42;  
	aang.col = 83;
	aang.rdel = 1;
	aang.cdel = 1;
	aang.open = center;
}

void initElem(void) {
	air.row = 1;
	air.col = 1;
	air.height = AIRICON_HEIGHT;
	air.width = AIRICON_WIDTH;
	air.image = airIcon;

	fire.row = 1;
	fire.col = (239-FIREICON_WIDTH);
	fire.height = FIREICON_HEIGHT;
	fire.width = FIREICON_WIDTH;
	fire.image = fireIcon;

	water.row = (159-WATERICON_HEIGHT);
	water.col = (239 - WATERICON_WIDTH);
	water.width = WATERICON_WIDTH;
	water.height = WATERICON_HEIGHT;
	water.image = waterIcon;

	earth.col = 1;
	earth.row = (159 - EARTHICON_HEIGHT);
	earth.height = EARTHICON_HEIGHT;
	earth.width = EARTHICON_WIDTH;
	earth.image = earthIcon;

	ballo.row = 1;
	ballo.col = 110;
	ballo.oldrow = ballo.row;
	ballo.oldcol = ballo.col;
	ballo.rdel = 2;
	ballo.cdel = 2;
	ballo.height = BALL_HEIGHT;
	ballo.width = BALL_WIDTH;
	ballo.open = ball;
}


