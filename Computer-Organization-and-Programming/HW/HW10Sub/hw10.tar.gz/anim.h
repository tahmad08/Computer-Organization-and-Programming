#ifndef ANIM_SEEN
#define ANIM_SEEN
#include "gba.h"
#include "logic.h"

extern int elem;
extern int collided;

void initAnim(void);
void initAang(void);
void initElem(void);
void drawAnim(void);
void drawBall(void);
void drawParts(void);
void updateAnim(unsigned short buttons, unsigned short oldButtons);
int updateBall(unsigned short buttons, unsigned short oldButtons, PLAYER *player);
void updateAang(int element);




#endif