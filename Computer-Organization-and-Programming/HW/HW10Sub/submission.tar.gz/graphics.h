#ifndef GRAPHICS_SEEN
#define GRAPHICS_SEEN

#include "logic.h"

int collision(PLAYER *player, OBJECT *object);
#endif
