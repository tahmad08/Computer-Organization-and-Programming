/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x17 arrow arrow.png 
 * Time-stamp: Monday 11/19/2018, 20:04:04
 * 
 * Image Information
 * -----------------
 * arrow.png 15@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ARROW_H
#define ARROW_H

extern const unsigned short arrow[255];
#define ARROW_SIZE 510
#define ARROW_LENGTH 255
#define ARROW_WIDTH 15
#define ARROW_HEIGHT 17

#endif

