/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 puppy1 puppy1.jpg 
 * Time-stamp: Saturday 11/03/2018, 21:36:04
 * 
 * Image Information
 * -----------------
 * puppy1.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PUPPY1_H
#define PUPPY1_H

extern const unsigned short puppy1[38400];
#define PUPPY1_SIZE 76800
#define PUPPY1_LENGTH 38400
#define PUPPY1_WIDTH 240
#define PUPPY1_HEIGHT 160

#endif

