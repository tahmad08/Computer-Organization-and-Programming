/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 puppy4 puppy4.jpg 
 * Time-stamp: Saturday 11/03/2018, 21:36:17
 * 
 * Image Information
 * -----------------
 * puppy4.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PUPPY4_H
#define PUPPY4_H

extern const unsigned short puppy4[38400];
#define PUPPY4_SIZE 76800
#define PUPPY4_LENGTH 38400
#define PUPPY4_WIDTH 240
#define PUPPY4_HEIGHT 160

#endif

