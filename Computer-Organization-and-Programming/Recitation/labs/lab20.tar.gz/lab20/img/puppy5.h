/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 puppy5 puppy5.jpg 
 * Time-stamp: Saturday 11/03/2018, 21:36:21
 * 
 * Image Information
 * -----------------
 * puppy5.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PUPPY5_H
#define PUPPY5_H

extern const unsigned short puppy5[38400];
#define PUPPY5_SIZE 76800
#define PUPPY5_LENGTH 38400
#define PUPPY5_WIDTH 240
#define PUPPY5_HEIGHT 160

#endif

