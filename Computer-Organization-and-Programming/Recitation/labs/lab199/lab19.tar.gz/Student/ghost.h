/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=56x60 ghost ghost.png 
 * Time-stamp: Tuesday 10/30/2018, 14:55:58
 * 
 * Image Information
 * -----------------
 * ghost.png 56@60
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GHOST_H
#define GHOST_H

extern const unsigned short ghost[3360];
#define GHOST_SIZE 6720
#define GHOST_LENGTH 3360
#define GHOST_WIDTH 56
#define GHOST_HEIGHT 60

#endif

