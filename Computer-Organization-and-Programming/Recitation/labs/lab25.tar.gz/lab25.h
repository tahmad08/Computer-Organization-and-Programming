#ifndef LAB25_H
#define LAB25_H

extern void reverse_short_array(const short *arr_in, short *arr_out, int len);

#endif
