extern Suite *bst_suite(void);
